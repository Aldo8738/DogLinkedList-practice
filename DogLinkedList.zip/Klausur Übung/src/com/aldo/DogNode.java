package com.aldo;

public class DogNode {

    public DogNode next;
    public Dogs dog;

    public DogNode(Dogs dog) {
        this.next = null;
        this.dog = dog;
    }

    @Override
    public String toString() {
        return "Dog Information: \nDog Name: " + dog.getName() + "\nDog Breed: " + dog.getBreed() + "\nColor: " + dog.getColor() + "\nNumber of Legs: " + dog.getNumberOfLegs();
    }
}
