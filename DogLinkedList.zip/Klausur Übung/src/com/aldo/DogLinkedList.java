package com.aldo;

public class DogLinkedList {
    DogNode front;

    public DogLinkedList() {
        this.front = null;
    }

    public boolean isEmpty() {
        return front == null;
    }

    public void addFront(Dogs dog) {
        DogNode node = new DogNode(dog);
        node.next = front;
        front = node;
    }

    public void addAt(int position, Dogs dog) {
        DogNode node = this.front;
        if (position == 0) {
            addFront(dog);
        } else {
            for (int i = 1; node != null && i < position; i++) {
                node = node.next;
            }
            if (node != null) {
                add(node, dog);
            }
        }
    }

    public void add(DogNode it, Dogs dog) {
        if (it == null ) {
            System.out.println("Cannot insert after null");
            return;
        }
        DogNode node = new DogNode(dog);
        node.next = it.next;
        it.next = node;
    }

    public void remove(Dogs dog) {
        if ((front != null && front.dog.equals(dog))) {
            front = front.next;
        } else if (front != null) {
            DogNode it = front;
            while (it.next != null) {
                DogNode node = it.next;
                if (node.dog.equals(dog)) {
                    it.next = node.next;
                    break;
                } else {
                    it = it.next;
                }
            }
        }
    }

    public void printContent() {
        for (DogNode node = front; node != null; node = node.next) {
            System.out.println(node.toString());
            System.out.println();
        }
    }
}
