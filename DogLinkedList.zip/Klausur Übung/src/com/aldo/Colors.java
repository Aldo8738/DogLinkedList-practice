package com.aldo;

public enum Colors {
    BLACK, WHITE, BROWN, SPOTS
}
