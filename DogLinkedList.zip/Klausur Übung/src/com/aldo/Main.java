package com.aldo;

public class Main {

    public static void main(String[] args) {
	DogLinkedList linkedList = new DogLinkedList();
	linkedList.addFront(new Dogs("Dolly",3, Colors.BLACK, Breed.BEAGLE));
	Dogs lolo = new Dogs("Lolo", 4, Colors.BLACK, Breed.BULLDOG);
	linkedList.addAt(1, lolo);
	linkedList.printContent();
    }
}
