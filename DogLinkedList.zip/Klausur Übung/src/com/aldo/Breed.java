package com.aldo;

public enum Breed {
    CHIHUAHUA, BULLDOG, SHEPHARD, BEAGLE, SCHNAUTZER
}
