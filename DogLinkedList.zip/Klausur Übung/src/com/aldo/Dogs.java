package com.aldo;

public class Dogs {
    private String name;
    private int numberOfLegs;
    private Colors color;
    private Breed breed;

    public Dogs(String name, int numberOfLegs, Colors color, Breed breed) {
        this.name = name;
        this.numberOfLegs = numberOfLegs;
        this.color = color;
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public int getNumberOfLegs() {
        return numberOfLegs;
    }

    public Colors getColor() {
        return color;
    }

    public Breed getBreed() {
        return breed;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumberOfLegs(int numberOfLegs) {
        this.numberOfLegs = numberOfLegs;
    }

    public void setColor(Colors color) {
        this.color = color;
    }

    public void setBreed(Breed breed) {
        this.breed = breed;
    }
}
